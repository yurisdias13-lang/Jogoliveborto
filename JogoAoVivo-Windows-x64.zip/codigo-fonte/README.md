# Jogo ao vivo

Aplicativo local em português brasileiro inspirado em Family Feud. Motor de regras independente, painel privado, telão público e SQLite. Não exige Twitch, OBS ou IA para jogar. Não utiliza IA local nem hospedagem externa.

## Executar no ambiente de desenvolvimento

Python 3.12 ou superior. Use o checkout existente; cada tarefa na nuvem já é isolada.

```bash
cd /workspace/Jogoliveborto
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python main.py --data-dir /workspace/.jogoliveborto
```

No Windows, use `.venv\Scripts\python.exe` no lugar de `.venv/bin/python`. Na nuvem, o argumento `--data-dir` mantém os dados em uma pasta gravável. Em uma instalação local normal ele pode ser omitido. O comando abre o painel no navegador com autorização privada no fragmento da URL. Não compartilhe essa janela ou seu token. `--no-browser` serve para testes HTTP automatizados; não imprime o token. `--data-dir CAMINHO` permite selecionar um diretório de dados de teste. A porta padrão é 8765, exclusivamente em loopback.

O telão está na rota `/public` do serviço local e pode ser aberto pelo botão **Abrir telão**, ou adicionado manualmente como fonte de navegador do OBS no próprio computador. Não coloque o painel administrativo no OBS. Respostas ocultas, sinônimos, votos e resultado ainda não confirmado não são enviados ao endpoint público.

## Fluxo offline

1. Cadastre perguntas no banco, com uma resposta por linha: `texto | pontos | sinônimo, outro sinônimo`. Revise e marque como aprovada. Ou importe `examples/perguntas.json`, revise e aprove cada pergunta.
2. Crie a partida escolhendo modalidade, participantes, chat, tempo, erros, rodadas e multiplicador.
3. Sorteie uma pergunta ou escolha manualmente. O sorteio evita reutilização na partida e informa quando o banco acaba.
4. Confira a resposta digitada ou revele uma posição manualmente. Registre erros; quando o limite é alcançado, confirme o próximo turno sugerido.
5. O chat desafiante só é habilitado depois das falhas de todos os elegíveis. Autorize a votação, simule mensagens ou receba mensagens reais de uma conexão Twitch. Usuário é identificado por ID, novo voto substitui o anterior e mensagens duplicadas são recusadas.
6. O tempo congela a votação. Confira o resultado privado e confirme a revelação. Pontos são atribuídos uma vez. Sem votos ou resposta incorreta não há roubo.
7. Encerre rodadas sem vencedor para continuar. O maior placar vence após a última rodada; empates abrem rodada extra apenas para os líderes.
8. Use **Salvar partida** explicitamente. Carregar exige confirmação para descartar alterações pendentes. Não há autosave de partidas. `Desfazer` mantém até 100 ações em memória; o histórico de desfazer não é restaurado ao carregar.

As simulações de espectadores são identificadas no painel. Pontuações do pacote de exemplo são inventadas, não resultados de pesquisas.

## Integrações opcionais

**OBS Studio 28+ / WebSocket 5:** ative o servidor em Ferramentas, informe porta e senha no painel. Detecte as fontes e associe até cinco por JSON, com coordenadas e dimensões. O adaptador cria uma cena de nome exclusivo e referencia fontes existentes; não remove fontes ou altera outras cenas. Destaque e restauração usam IDs retornados no painel. Layouts ficam no armazenamento local do painel. Uma falha não interrompe a partida; uma operação posterior tenta reconectar quando a conexão está marcada como interrompida. Os nomes informados em `name` geram fontes de texto na cena do aplicativo. Composição e ordenação de camadas ainda precisam de validação no OBS real.

**Twitch:** cadastre um aplicativo público em `dev.twitch.tv/console`, obtenha o Client ID e use o fluxo de código de dispositivo do painel. O servidor pede `user:read:chat`, valida a identidade e conecta ao EventSub WebSocket oficial. São usados ID do usuário e ID da mensagem. Tokens ficam somente na memória, com tentativa de renovação enquanto o processo permanece aberto. Ao reiniciar é necessário autorizar de novo. O aplicativo precisa de acesso a `id.twitch.tv`, `api.twitch.tv` e `eventsub.wss.twitch.tv`. Esta integração não foi validada com uma conta Twitch real.

**IA externa:** provedor compatível com OpenAI Chat Completions em HTTPS. Modelo e chave podem ser informados por pedido ou por `.env` na pasta de execução (copie `.env.example`). Variáveis de processo existentes têm precedência. A geração faz uma chamada real e só preenche um rascunho no editor; exige revisão, edição e aprovação antes de salvar. Pontos são identificados como simulados. Duplicatas próximas são sinalizadas por comparação textual conservadora. Credenciais não são inseridas no JavaScript, SQLite ou logs. A conexão não foi validada com credenciais reais; não é necessária para jogar. Para o endpoint padrão, libere `api.openai.com` nas configurações de rede.

## Importação e exportação

JSON: lista de perguntas com `text`, `category`, `difficulty`, `origin`, `answers` (lista de `text`, `points` inteiro e `synonyms`). CSV/XLSX: cabeçalhos equivalentes, com `answers` contendo a lista JSON. CSV aceita mapeamento opcional de colunas; no XLSX o mapeamento também é aplicado aos cabeçalhos. Limites: 2 MB por pedido, 2000 linhas, 20 MB descompactados para XLSX. Primeira planilha apenas. A prévia exibe válidas e erros e não escreve no banco. Confirme somente as válidas ou cancele. A prévia permite marcar somente as linhas desejadas; a API `import_confirm` também aceita `indices`. Todas entram sem aprovação. Exportação JSON compartilha somente o banco de perguntas, sem partidas ou credenciais.

## Windows

Execute `build-windows.ps1` no Windows com Python 3.12 instalado. O script instala dependências, executa os testes e usa PyInstaller para gerar `dist/JogoAoVivo.exe`, versão portátil. A entrada `desktop.py` usa pywebview para incorporar a interface, abrir os serviços automaticamente e encerrá-los ao sair. O Windows precisa do WebView2 Runtime (Edge). Dados ficam em `%LOCALAPPDATA%\Jogoliveborto`. O telão usa a porta fixa 8765; outra instância usando a porta deve ser encerrada antes.

**Foi gerado um executável Windows x64 com Python 3.12.10 e PyInstaller 6.11.1 sob Wine.** Os 31 testes passaram com Python para Windows, e o executável passou no teste funcional não gráfico sob Wine 10, sem acesso ao código-fonte. A janela incorporada e as integrações ainda precisam de validação em um Windows real. A versão portátil não é assinada. Não há instalador nesta etapa. Consulte `docs/COMPILACAO.md`.

## Validação e status

- 31 testes automatizados de regras, autenticação HTTP, isolamento do telão, SQLite e importação.
- Teste funcional Chromium: cadastro, aprovação, criação de partida, início de rodada, revelação, sigilo das respostas restantes e salvamento.
- IA, Twitch e OBS têm adaptadores reais, mas testes com serviços reais dependem das contas/aplicativos do usuário e de OBS em execução. Nenhuma conexão é apresentada como validada sem essa evidência.
- V1 ainda não pode ser considerada concluída: faltam validação da interface em Windows real e das integrações, refinamento e validação dos layouts com câmeras e rótulos, além de políticas adicionais de roubo. Regras especiais por rodada aceitam JSON com `seconds`, `vote_seconds`, `errors` e `multiplier` no painel antes de iniciar a rodada. O roubo do chat exige falha de todos os elegíveis.

Efeitos originais sintetizados apenas no telão; ative o áudio com um clique. Há volume geral, volumes por efeito e silenciamento por volume zero. Atalhos são configuráveis em Configurações. O serviço não deve ser exposto na rede: o token local é uma proteção do painel, não uma autorização para hospedar o aplicativo publicamente.
