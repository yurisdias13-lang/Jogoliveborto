"""Entrada Windows com interface incorporada e encerramento dos serviços."""
import logging
import os
from pathlib import Path
import threading
import sys
from http.server import ThreadingHTTPServer
from feud.server import App, handler


def main():
    import webview
    folder=Path(os.getenv('LOCALAPPDATA',str(Path.home()))) / 'Jogoliveborto'
    folder.mkdir(parents=True,exist_ok=True)
    logging.basicConfig(filename=folder/'erros.log',level=logging.ERROR)
    app=App(folder/'jogo.sqlite3')
    server=ThreadingHTTPServer(('127.0.0.1',8765),handler(app))
    thread=threading.Thread(target=server.serve_forever,daemon=True)
    thread.start()
    window=webview.create_window('Jogo ao vivo • Apresentador',f'http://127.0.0.1:8765/#token={app.token}',width=1440,height=900,min_size=(960,640))
    def closing():
        if app.game.dirty:
            return window.create_confirmation_dialog('Alterações não salvas','Encerrar sem salvar a partida?')
        return True
    window.events.closing += closing
    try: webview.start(gui='edgechromium')
    finally:
        server.shutdown()
        server.server_close()
        app.twitch.disconnect()
        app.obs.disconnect()
        app.store.db.close()

if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--self-test':
        from feud.selftest import run
        raise SystemExit(run(sys.argv[2]))
    try:
        main()
    except Exception as error:
        logging.exception('Falha de inicialização')
        if sys.platform == 'win32':
            import ctypes
            ctypes.windll.user32.MessageBoxW(None,
                'Não foi possível iniciar o aplicativo. Verifique se a porta 8765 está livre e se o Microsoft Edge WebView2 Runtime está instalado.\n\n' + str(error),
                'Jogo ao vivo — erro ao iniciar', 0x10)
        else:
            raise

