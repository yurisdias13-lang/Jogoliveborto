'use strict';
const $=id=>document.getElementById(id);
let audio,previous=null;
$('audio').onclick=()=>{audio=new AudioContext();audio.resume();$('audio').hidden=true;};
function sound(freq=650,effect='revelacao'){if(!audio)return;const o=audio.createOscillator(),g=audio.createGain();o.type='sine';o.frequency.setValueAtTime(freq,audio.currentTime);o.frequency.exponentialRampToValueAtTime(freq*1.5,audio.currentTime+.2);g.gain.setValueAtTime(Number(localStorage.getItem('volume')??.3)*Number(JSON.parse(localStorage.getItem('effectVolumes')||'{}')[effect]??1)*.2,audio.currentTime);g.gain.exponentialRampToValueAtTime(.001,audio.currentTime+.35);o.connect(g);g.connect(audio.destination);o.start();o.stop(audio.currentTime+.4);}
function el(tag,text,cls){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;}
async function poll(){try{const r=await fetch('/api/public');if(!r.ok)throw Error();const s=await r.json();$('connection').textContent='';$('stageRound').textContent='RODADA '+(s.round||'—');$('stagePhase').textContent=s.phase.toUpperCase();$('stageQuestion').textContent=s.question||'A partida vai começar';$('stageClock').textContent=(s.seconds??'—')+'s';
const sig=JSON.stringify(s.answers);if(sig!==previous?.sig){$('board').replaceChildren(...s.answers.map(a=>{const c=el('div',undefined,'tile '+(a.text?'revealed':''));c.append(el('span',a.number,'number'),el('strong',a.text||'••••••••'),el('span',a.text?a.points:'','points'));return c;}));if(previous&&s.answers.filter(a=>a.text).length>previous.revealed)sound();}
$('stageScores').replaceChildren(...s.players.map(n=>{const c=el('div',undefined,'score '+(s.turn===n?'current':''));c.append(el('span',n),el('strong',s.scores[n]));return c;}));$('stageTurn').textContent=s.turn?'Vez de '+s.turn:'';$('stagePot').textContent='BANCO · '+(s.pot||0);$('stageErrors').textContent='✕ '.repeat(s.errors?.[s.turn]||0);$('stageWinner').textContent=s.winner?.length?'🏆 '+s.winner.join(' · '):'';
const errors=Object.values(s.errors||{}).reduce((a,b)=>a+b,0);if(previous&&errors>previous.errors)sound(150,'erro');
if(previous&&s.phase!==previous.phase){if(s.phase==='votação')sound(400,'inicio');if(s.phase==='resultado pendente')sound(350,'fim');if(s.phase==='aguardando chat')sound(220,'suspense');if(s.phase==='encerrada')sound(500,s.turn==='Chat'?'roubo':'encerramento');if(s.phase==='finalizada')sound(900,'vitoria');}
if(previous&&s.seconds!==previous.seconds&&s.seconds<=5&&s.seconds>0)sound(750,'contagem');
document.body.classList.toggle('voting',s.phase==='votação');document.body.classList.toggle('victory',s.phase==='finalizada');
previous={sig,revealed:s.answers.filter(a=>a.text).length,errors,phase:s.phase,seconds:s.seconds};}catch(e){$('connection').textContent='Conexão local interrompida. Tentando reconectar…';}}
poll();setInterval(poll,500);
