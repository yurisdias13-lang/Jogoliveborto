'use strict';
const $ = id => document.getElementById(id);
const token = new URLSearchParams(location.hash.slice(1)).get('token');
if (token) { sessionStorage.setItem('adminToken', token); history.replaceState(null, '', '/'); }
let snapshot, signature = '', saveKey = localStorage.getItem('saveKey') || 's';
function notify(message, bad=false) { $('notice').textContent=message; $('notice').className=bad?'bad':'good'; }
function element(tag, text, cls) {const e=document.createElement(tag); if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;}
async function api(path, data) {
 const r=await fetch('/api/'+path,{method:data===undefined?'GET':'POST',headers:{'Content-Type':'application/json','X-Admin-Token':sessionStorage.getItem('adminToken')||''},body:data===undefined?undefined:JSON.stringify(data)});
 const result=await r.json(); if(!r.ok)throw Error(result.error); return result;
}
async function command(action,data={}) {try {const result=await api(action,data);await refresh();notify('Ação concluída.');return result;}catch(e){notify(e.message,true);return null;}}
function tab(id) {document.querySelectorAll('.tab').forEach(e=>e.classList.toggle('hidden',e.id!==id));document.querySelectorAll('[data-tab]').forEach(e=>e.classList.toggle('active',e.dataset.tab===id));}
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>tab(b.dataset.tab));
document.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>{if(['finish','reset_round','end_game'].includes(b.dataset.action)&&!confirm('Confirmar esta ação na rodada?'))return;command(b.dataset.action);});
async function refresh() {
 const data=await api('admin');snapshot=data;
 $('twitchStatus').textContent=data.integrations.twitch;$('obsStatus').textContent=data.integrations.obs;
 const s=data.state;
 $('dirty').textContent=data.dirty?'● Alterações não salvas':s?'✓ Partida salva':'Sem partida';
 if(s) {
 $('phase').textContent=s.phase;$('round').textContent='Rodada '+s.round+' · Banco: '+s.pot+' pontos';
 $('question').textContent=s.question?.text||'Selecione uma pergunta aprovada';
 $('clock').textContent=(s.deadline?Math.max(0,Math.ceil(s.deadline-Date.now()/1000)):Math.ceil(s.remaining))+'s';
 $('turn').textContent='Vez de: '+s.turn+(s.pending_turn?' · Confirme o próximo turno: '+s.pending_turn:'')+(s.winner.length?' · Vencedor: '+s.winner.join(', '):'');
 $('scores').replaceChildren(...s.players.map(n=>element('div',n+' · '+s.scores[n]+' pontos','score')));
 $('answers').replaceChildren(...(s.question?.answers||[]).map((a,i)=>{let b=element('button',(i+1)+'. '+a.text+' · '+a.points+' pts'+(s.revealed.includes(i)?' ✓':''),'answer');b.disabled=s.revealed.includes(i);b.onclick=()=>command('reveal',{index:i});return b;}));
 $('votes').replaceChildren();
 if(s.phase==='votação'){let counts=Object.create(null);Object.values(s.votes).forEach(v=>counts[v]=(counts[v]||0)+1);Object.entries(counts).sort((a,b)=>b[1]-a[1]).forEach(([k,v])=>$('votes').append(element('p',k+': '+v)));}
 if(s.phase==='resultado pendente')$('votes').append(element('p','Resultado privado: '+(s.vote_result.answer||'Sem votos')+' · '+(s.vote_result.correct?'Correta':'Incorreta')+'. Aguarda sua confirmação.'));
 const players=s.players.join('|');if($('scorePlayer').dataset.players!==players){$('scorePlayer').replaceChildren(...s.players.map(n=>{let o=element('option',n);o.value=n;return o;}));$('scorePlayer').dataset.players=players;}
 }
 const sig=JSON.stringify([data.questions,data.saves]);
 if(sig!==signature){ signature=sig;
 const selected=$('questionChoice').value;
 $('questionChoice').replaceChildren(element('option','Sortear pergunta não utilizada'));$('questionChoice').firstChild.value='';
 data.questions.filter(q=>q.approved).forEach(q=>{const o=element('option',q.text);o.value=q.id;$('questionChoice').append(o);});$('questionChoice').value=selected;
 $('questions').replaceChildren(...data.questions.map(q=>{const c=element('div',undefined,'panel');c.append(element('h3',q.text),element('p',q.category+' · '+(q.approved?'Aprovada':'Aguardando revisão')));const b=element('button','Editar / aprovar');b.onclick=()=>{const f=$('questionForm');['id','text','category','difficulty','origin'].forEach(k=>f.elements[k].value=q[k]||'');f.elements.approved.checked=q.approved;f.elements.answers.value=q.answers.map(a=>[a.text,a.points,(a.synonyms||[]).join(', ')].join(' | ')).join('\n');};c.append(b);return c;}));
 $('savedGames').replaceChildren(...data.saves.map(sv=>{const c=element('div',undefined,'panel');c.append(element('h3',sv.name),element('p',new Date(sv.updated).toLocaleString('pt-BR')));const b=element('button','Carregar');b.onclick=async()=>{const discard=!snapshot.dirty||confirm('Descartar alterações não salvas e carregar esta partida?');if(discard){await command('load',{id:sv.id,discard:true});tab('live');}};c.append(b);return c;}));
 }
}
$('setupForm').onsubmit=async e=>{e.preventDefault();if(snapshot?.dirty&&!confirm('Descartar a partida atual?'))return;const f=new FormData(e.target),d=Object.fromEntries(f);d.players=d.players.split('\n').map(x=>x.trim()).filter(Boolean);d.chat=f.has('chat');if(await command('create',d))tab('live');};
$('questionForm').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target),q=Object.fromEntries(f);if(!q.id)delete q.id;q.approved=f.has('approved');q.answers=q.answers.split('\n').filter(x=>x.trim()).map(line=>{const [text,points,synonyms='']=line.split('|').map(x=>x.trim());return {text,points:Number(points),synonyms:synonyms.split(',').map(x=>x.trim()).filter(Boolean)};});await command('question',q);};
$('answerForm').onsubmit=async e=>{e.preventDefault();await command('answer',{text:$('answer').value});$('answer').value='';};
$('voteForm').onsubmit=e=>{e.preventDefault();command('vote',{user:$('voter').value,text:$('vote').value,message_id:crypto.randomUUID()});};
$('scoreForm').onsubmit=e=>{e.preventDefault();command('score',{player:$('scorePlayer').value,score:$('scoreValue').value});};
$('newRound').onclick=()=>{try{command('round',{id:$('questionChoice').value,rules:$('roundRules').value?JSON.parse($('roundRules').value):undefined});}catch(e){notify(e.message,true);}};
$('save').onclick=()=>{const name=prompt('Nome da partida','Partida ao vivo');if(name!==null)command('save',{name});};
$('file').onchange=async e=>{const f=e.target.files[0];if(!f)return;if(f.size>1500000){notify('Arquivo muito grande.',true);return;}try{const mapping=$('mapping').value?JSON.parse($('mapping').value):undefined;const result=await command('import_preview',{text:f.name.toLowerCase().endsWith('.xlsx')?btoa(Array.from(new Uint8Array(await f.arrayBuffer()),v=>String.fromCharCode(v)).join('')):await f.text(),kind:f.name.toLowerCase().endsWith('.xlsx')?'xlsx':f.name.toLowerCase().endsWith('.csv')?'csv':'json',mapping});if(result){$('preview').replaceChildren(element('h3',result.valid.length+' válidas · '+result.errors.length+' erros'));result.valid.forEach((q,i)=>{const label=element('label');const check=element('input');check.type='checkbox';check.checked=true;check.value=i;check.className='importSelection';label.append(check,document.createTextNode(' '+q.text));$('preview').append(label);});result.errors.forEach(er=>$('preview').append(element('p','Linha '+er.row+': '+er.error)));}}catch(err){notify(err.message,true);}};
$('confirmImport').onclick=async()=>{if(confirm('Importar as perguntas válidas da prévia?')){await command('import_confirm',{indices:Array.from(document.querySelectorAll('.importSelection:checked'),c=>Number(c.value))});$('preview').replaceChildren();}};
$('cancelImport').onclick=async()=>{await command('import_cancel');$('preview').replaceChildren();$('file').value='';};
$('export').onclick=()=>{const url=URL.createObjectURL(new Blob([JSON.stringify(snapshot.questions,null,2)],{type:'application/json'}));const a=element('a');a.href=url;a.download='biblioteca.json';a.click();URL.revokeObjectURL(url);};
$('saveKey').value=saveKey;$('saveKey').oninput=e=>{saveKey=e.target.value.toLowerCase();localStorage.setItem('saveKey',saveKey);};
$('volume').value=localStorage.getItem('volume')||'.3';$('volume').oninput=e=>localStorage.setItem('volume',e.target.value);
document.addEventListener('keydown',e=>{if(e.ctrlKey&&e.key.toLowerCase()===saveKey){e.preventDefault();$('save').click();}});
window.addEventListener('beforeunload',e=>{if(snapshot?.dirty){e.preventDefault();e.returnValue='';}});
refresh().catch(e=>notify(e.message+' Abra o painel pela janela iniciada pelo aplicativo.',true));
setInterval(()=>refresh().catch(e=>notify(e.message,true)),1000);

$('aiForm').onsubmit=async e=>{e.preventDefault();const result=await command('ai_generate',Object.fromEntries(new FormData(e.target)));e.target.elements.key.value='';if(result){const f=$('questionForm');['text','category','difficulty','origin'].forEach(k=>f.elements[k].value=result[k]||'');f.elements.id.value='';f.elements.approved.checked=false;f.elements.answers.value=result.answers.map(a=>[a.text,a.points,(a.synonyms||[]).join(', ')].join(' | ')).join('\n');$('aiResult').textContent='Geração recebida; revise no banco. Possíveis duplicatas: '+(result.possible_duplicates.join('; ')||'nenhuma');tab('bank');}};
$('twitchForm').onsubmit=async e=>{e.preventDefault();const r=await command('twitch_device',Object.fromEntries(new FormData(e.target)));if(r)$('twitchAuth').textContent='Acesse '+r.verification_uri+' e informe '+r.user_code+'. Validade: '+r.expires_in+' s. Depois clique em verificar.';};
$('twitchAuthorize').onclick=()=>command('twitch_authorize',{channel:$('twitchChannel').value});
$('twitchDisconnect').onclick=()=>command('twitch_disconnect');
$('obsForm').onsubmit=async e=>{e.preventDefault();const r=await command('obs_connect',Object.fromEntries(new FormData(e.target)));e.target.elements.password.value='';if(r){$('obsSources').textContent=JSON.stringify(r,null,2);const cameras=r.inputs.slice(0,5).map((v,i)=>({source:v.inputName,name:'Participante '+(i+1),x:(i%2)*960,y:Math.floor(i/2)*360,width:960,height:360}));$('obsCameras').value=JSON.stringify(cameras,null,2);}};
$('obsLayout').onclick=async()=>{try{const r=await command('obs_layout',{cameras:JSON.parse($('obsCameras').value)});if(r){$('obsResult').textContent=JSON.stringify(r,null,2);localStorage.setItem('cameraLayout',$('obsCameras').value);}}catch(e){notify(e.message,true);}};
$('obsCameras').value=localStorage.getItem('cameraLayout')||'[]';
$('obsHighlight').onclick=()=>command('obs_highlight',{item_id:Number($('obsItem').value)});
$('obsRestore').onclick=()=>command('obs_restore');
$('obsDisconnect').onclick=()=>command('obs_disconnect');

let shortcuts=JSON.parse(localStorage.getItem('shortcuts')||'{"error":"e","timer":"t","next_turn":"n","finish":"f","undo":"z","reset_round":"r","open_vote":"v","close_vote":"c","confirm_vote":"a"}');
$('shortcuts').value=JSON.stringify(shortcuts,null,2);
$('shortcuts').onchange=e=>{try{const map=JSON.parse(e.target.value);if(!map||typeof map!=='object'||Array.isArray(map)||Object.values(map).some(v=>typeof v!=='string'||v.length!==1)||new Set(Object.values(map)).size!==Object.values(map).length)throw Error('Atalhos devem ter teclas únicas de um caractere.');shortcuts=map;localStorage.setItem('shortcuts',JSON.stringify(map));notify('Atalhos atualizados.');}catch(err){notify(err.message,true);}};
document.addEventListener('keydown',e=>{if(e.altKey&&!['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName)){const action=Object.keys(shortcuts).find(k=>shortcuts[k]===e.key.toLowerCase());if(action){e.preventDefault();const button=document.querySelector('[data-action="'+action+'"]');if(button)button.click();}}});
$('effectVolumes').value=localStorage.getItem('effectVolumes')||JSON.stringify({acerto:1,erro:1,revelacao:1,inicio:1,fim:1,contagem:1,suspense:.5,roubo:1,vitoria:1,encerramento:1},null,2);
$('effectVolumes').onchange=e=>{try{const v=JSON.parse(e.target.value);if(Object.values(v).some(n=>typeof n!=='number'||n<0||n>1))throw Error('Volumes devem estar entre 0 e 1.');localStorage.setItem('effectVolumes',JSON.stringify(v));notify('Volumes atualizados.');}catch(err){notify(err.message,true);}};
