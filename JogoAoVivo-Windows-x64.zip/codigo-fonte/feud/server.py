import argparse
import copy
import json
import logging
import os
from pathlib import Path
import random
import secrets
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
from .game import Game
from .store import Store
from .importing import preview
from .integrations import AI, OBS, Twitch

def load_env(path):
    if not path.is_file(): return
    for line in path.read_text(encoding='utf-8').splitlines():
        if not line.strip() or line.lstrip().startswith('#') or '=' not in line: continue
        key, value = line.split('=', 1)
        if key.strip() in ('FEUD_AI_KEY', 'FEUD_AI_MODEL', 'FEUD_AI_URL'):
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))

WEB = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent.parent)) / 'web'

class App:
    def __init__(self, database):
        load_env(Path.cwd() / '.env')
        self.game = Game()
        self.store = Store(database)
        self.lock = threading.RLock()
        self.token = secrets.token_urlsafe(32)
        self.pending_import = None
        self.save_id = None
        self.obs = OBS()
        self.ai = AI()
        self.twitch = Twitch(self.chat_message)
        self.ai_pending = None

    def chat_message(self, user, text, message_id):
        with self.lock:
            try:
                if self.game.state and self.game.state['phase'] == 'votação':
                    self.game.action('vote', dict(user=user, text=text, message_id=message_id))
            except ValueError:
                pass

    def admin(self):
        self.game.tick()
        return dict(state=self.game.state, dirty=self.game.dirty, questions=self.store.questions(), saves=self.store.saves(), integrations=dict(obs=self.obs.status, twitch=self.twitch.status))

    def command(self, action, data):
        if action == 'ai_generate':
            self.ai_pending = self.ai.generate(data)
            self.ai_pending['possible_duplicates'] = [q['text'] for q in self.store.questions() if __import__('difflib').SequenceMatcher(None, q['text'].casefold(), self.ai_pending['text'].casefold()).ratio() > .75]
            return self.ai_pending
        if action == 'obs_connect': return self.obs.connect(data)
        if action == 'obs_disconnect': self.obs.disconnect(); return {}
        if action == 'obs_layout': return self.obs.layout(data)
        if action == 'obs_highlight': return self.obs.highlight(data)
        if action == 'obs_restore': return self.obs.restore()
        if action == 'twitch_device': return self.twitch.device(data['client_id'])
        if action == 'twitch_authorize': return self.twitch.authorize(data['channel'])
        if action == 'twitch_disconnect': self.twitch.disconnect(); return {}
        if action == 'question': return self.store.put_question(data)
        if action == 'import_preview':
            if data['kind'] == 'xlsx':
                from .importing import xlsx_json
                data = dict(data, text=xlsx_json(data['text']), kind='json')
            self.pending_import = preview(data['text'], data['kind'], self.store.questions(), data.get('mapping'))
            return self.pending_import
        if action == 'import_cancel': self.pending_import = None; return {}
        if action == 'import_confirm':
            if not self.pending_import: raise ValueError('Faça a prévia primeiro.')
            selected = data.get('indices', list(range(len(self.pending_import['valid']))))
            if not isinstance(selected, list) or any(type(i) is not int or not 0 <= i < len(self.pending_import['valid']) for i in selected): raise ValueError('Seleção inválida.')
            for i in sorted(set(selected)): self.store.put_question(self.pending_import['valid'][i])
            self.pending_import = None
            return {}
        if action == 'save':
            self.save_id = self.store.save(self.game.state, data.get('name', 'Partida'), self.save_id)
            self.game.dirty = False
            return {}
        if action == 'load':
            if self.game.dirty and not data.get('discard'): raise ValueError('Salve a partida ou confirme o descarte das alterações.')
            state = self.store.load(data['id'])
            self.game.state, self.game.history, self.game.dirty = state, [], False
            self.save_id = data['id']
            return {}
        if action == 'round':
            s = self.game.state
            if not s: raise ValueError('Crie uma partida.')
            qs = [q for q in self.store.questions() if q['approved']]
            if data.get('id'):
                qs = [q for q in qs if q['id'] == data['id']]
            else:
                qs = [q for q in qs if q['id'] not in s['used']]
                if not qs: raise ValueError('Banco aprovado esgotado. Escolha manualmente ou cadastre mais perguntas.')
            if not qs: raise ValueError('Pergunta aprovada não encontrada.')
            q = copy.deepcopy(random.choice(qs))
            if data.get('rules'): q['rules'] = data['rules']
            self.game.action('round', {'question': q})
            from datetime import datetime, timezone
            original = next(item for item in self.store.questions() if item['id'] == q['id'])
            original.setdefault('history', []).append(datetime.now(timezone.utc).isoformat())
            self.store.put_question(original)
            return {}
        self.game.action(action, data)
        if action == 'create': self.save_id = None
        return {}

def handler(app):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            # Não registrar tokens nem corpos de pedidos.
            pass

        def send(self, status, value, kind='application/json; charset=utf-8'):
            body = json.dumps(value, ensure_ascii=False).encode() if kind.startswith('application/json') else value
            self.send_response(status)
            self.send_header('Content-Type', kind)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Referrer-Policy', 'no-referrer')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(body)

        def authorized(self):
            return secrets.compare_digest(self.headers.get('X-Admin-Token', ''), app.token)

        def allowed_host(self):
            return self.headers.get('Host') in (f'127.0.0.1:{self.server.server_port}', f'localhost:{self.server.server_port}')

        def do_GET(self):
            if not self.allowed_host(): return self.send(403, {'error': 'Host inválido.'})
            path = urlparse(self.path).path
            with app.lock:
                if path == '/api/public': return self.send(200, app.game.public())
                if path == '/api/admin':
                    if not self.authorized(): return self.send(401, {'error': 'Acesso restrito ao apresentador.'})
                    return self.send(200, app.admin())
            paths = {'/': 'index.html', '/public': 'public.html', '/app.js': 'app.js', '/public.js': 'public.js', '/style.css': 'style.css'}
            if path not in paths: return self.send(404, {'error': 'Não encontrado.'})
            file = WEB / paths[path]
            mime = 'text/html; charset=utf-8' if file.suffix == '.html' else 'text/javascript; charset=utf-8' if file.suffix == '.js' else 'text/css; charset=utf-8'
            self.send(200, file.read_bytes(), mime)

        def do_POST(self):
            if not self.allowed_host() or not self.authorized(): return self.send(403, {'error': 'Acesso negado.'})
            origin = self.headers.get('Origin')
            if origin and origin not in (f'http://127.0.0.1:{self.server.server_port}', f'http://localhost:{self.server.server_port}'):
                return self.send(403, {'error': 'Origem inválida.'})
            try:
                size = int(self.headers.get('Content-Length', '0'))
                if not 0 < size <= 2_000_000: raise ValueError('Tamanho do pedido inválido.')
                data = json.loads(self.rfile.read(size))
                if not isinstance(data, dict): raise ValueError('Objeto JSON obrigatório.')
                with app.lock:
                    result = app.command(urlparse(self.path).path.removeprefix('/api/'), data)
                self.send(200, result)
            except (ValueError, KeyError, TypeError, OverflowError) as e:
                self.send(400, {'error': str(e)})
            except Exception:
                logging.exception('Falha técnica')
                self.send(500, {'error': 'Erro técnico. Consulte o registro local.'})
    return Handler

def main():
    parser = argparse.ArgumentParser(description='Family Feud local')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--data-dir', type=Path, default=Path(os.getenv('LOCALAPPDATA', str(Path.home() / '.local/share'))) / 'Jogoliveborto')
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    args.data_dir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(filename=args.data_dir / 'erros.log', level=logging.ERROR)
    app = App(args.data_dir / 'jogo.sqlite3')
    server = ThreadingHTTPServer(('127.0.0.1', args.port), handler(app))
    url = f'http://127.0.0.1:{server.server_port}/#token={app.token}'
    if not args.no_browser: webbrowser.open(url)
    # O token fica apenas no fragmento da janela privada; nunca nos logs.
    print(f'Serviço local iniciado na porta {server.server_port}. Ctrl+C encerra.')
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally:
        server.server_close()
        app.twitch.disconnect()
        app.obs.disconnect()
        app.store.db.close()

if __name__ == '__main__': main()
