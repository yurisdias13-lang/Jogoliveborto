import copy
import json
import sqlite3
import uuid
from datetime import datetime, timezone
from .game import validate_question

class Store:
    def __init__(self, path):
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.execute('CREATE TABLE IF NOT EXISTS questions (id TEXT PRIMARY KEY, data TEXT NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS saves (id TEXT PRIMARY KEY, name TEXT NOT NULL, data TEXT NOT NULL, updated TEXT NOT NULL)')
        self.db.commit()

    def questions(self):
        return [json.loads(row[0]) for row in self.db.execute('SELECT data FROM questions ORDER BY rowid')]

    def put_question(self, q):
        q = copy.deepcopy(validate_question(q))
        q.setdefault('id', str(uuid.uuid4()))
        q.setdefault('created', datetime.now(timezone.utc).isoformat())
        q['updated'] = datetime.now(timezone.utc).isoformat()
        q.setdefault('history', [])
        q.setdefault('origin', 'Cadastro manual; pontuação simulada')
        q.setdefault('category', 'Personalizadas')
        q.setdefault('difficulty', 'Normal')
        q['approved'] = bool(q.get('approved', False))
        with self.db:
            self.db.execute('INSERT INTO questions VALUES (?, ?) ON CONFLICT(id) DO UPDATE SET data=excluded.data', (q['id'], json.dumps(q, ensure_ascii=False)))
        return q

    def save(self, state, name, save_id=None):
        if not state: raise ValueError('Nenhuma partida para salvar.')
        state = copy.deepcopy(state)
        if state['deadline']:
            import time
            state['remaining'] = max(0, state['deadline'] - time.time())
            state['deadline'] = None
        save_id = save_id or str(uuid.uuid4())
        with self.db:
            self.db.execute('INSERT INTO saves VALUES (?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET name=excluded.name, data=excluded.data, updated=excluded.updated',
                (save_id, str(name).strip()[:100] or 'Partida', json.dumps(state), datetime.now(timezone.utc).isoformat()))
        return save_id

    def saves(self):
        return [dict(zip(('id', 'name', 'updated'), row)) for row in self.db.execute('SELECT id, name, updated FROM saves ORDER BY updated DESC')]

    def load(self, save_id):
        row = self.db.execute('SELECT data FROM saves WHERE id=?', (save_id,)).fetchone()
        if not row: raise ValueError('Partida não encontrada.')
        s = json.loads(row[0])
        if s['phase'] == 'votação':
            import time
            s['deadline'] = time.time() + s['remaining']
        return s
