"""Verificação não interativa do executável empacotado, sem credenciais."""
import base64
import io
import json
from pathlib import Path
import tempfile
import threading
from http.server import ThreadingHTTPServer
from urllib.request import Request, urlopen
from .server import App, WEB, handler
from .importing import preview, xlsx_json


def run(report_path):
    report = {'passed': False, 'checks': []}
    server = None
    app = None
    try:
        with tempfile.TemporaryDirectory() as folder:
            app = App(Path(folder) / 'smoke.sqlite3')
            for filename in ('index.html', 'public.html', 'app.js', 'public.js', 'style.css'):
                assert (WEB / filename).is_file(), 'Recurso ausente: ' + filename
            report['checks'].append('Recursos web incorporados')
            server = ThreadingHTTPServer(('127.0.0.1', 0), handler(app))
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            url = f'http://127.0.0.1:{server.server_port}'
            def request(path, data=None, private=True):
                headers = {'Content-Type': 'application/json'}
                if private: headers['X-Admin-Token'] = app.token
                req = Request(url + path, headers=headers, data=None if data is None else json.dumps(data).encode())
                with urlopen(req, timeout=10) as response:
                    return json.load(response)
            q = {'text': 'Verificação de distribuição', 'approved': True, 'answers': [
                {'text': 'Resposta secreta alfa', 'points': 60, 'synonyms': []},
                {'text': 'Resposta secreta beta', 'points': 40, 'synonyms': []}]}
            question = request('/api/question', q)
            request('/api/create', {'players': ['Time A', 'Time B']})
            request('/api/round', {'id': question['id']})
            public = request('/api/public', private=False)
            assert all('text' not in a for a in public['answers'])
            report['checks'].append('Servidor HTTP e sigilo de respostas')
            request('/api/reveal', {'index': 0})
            public = request('/api/public', private=False)
            assert public['answers'][0]['text'] == 'Resposta secreta alfa'
            assert 'text' not in public['answers'][1]
            request('/api/save', {'name': 'Verificação'})
            save_id = request('/api/admin')['saves'][0]['id']
            request('/api/reveal', {'index': 1})
            request('/api/load', {'id': save_id, 'discard': True})
            assert app.game.state['revealed'] == [0]
            report['checks'].append('Regras e persistência SQLite')
            from openpyxl import Workbook
            book = Workbook()
            book.active.append(['text', 'answers'])
            book.active.append([q['text'], json.dumps(q['answers'])])
            binary = io.BytesIO()
            book.save(binary)
            result = preview(xlsx_json(base64.b64encode(binary.getvalue()).decode()), 'json', [])
            assert len(result['valid']) == 1
            report['checks'].append('Importação XLSX e dependências empacotadas')
            server.shutdown()
            server.server_close()
            thread.join(timeout=5)
            server = None
            app.store.db.close()
            app = None
            report['passed'] = True
    except Exception as error:
        report['error'] = f'{type(error).__name__}: {error}'
    finally:
        if server:
            server.shutdown()
            server.server_close()
        if app: app.store.db.close()
        Path(report_path).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    return 0 if report['passed'] else 1
