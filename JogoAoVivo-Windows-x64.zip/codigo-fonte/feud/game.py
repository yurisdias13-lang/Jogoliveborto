"""Regras independentes de interfaces e integrações."""
import copy
import re
import time
import unicodedata
from collections import Counter

MODES = ['Individual contra chat', 'Equipe contra chat', 'Duas equipes', 'Solo com desafiante', 'Competição individual']

def normalize(value):
    value = unicodedata.normalize('NFKD', str(value).casefold())
    return ' '.join(re.sub(r'[^\w\s]', ' ', ''.join(c for c in value if not unicodedata.combining(c))).split())

def validate_question(q):
    if not isinstance(q, dict) or not str(q.get('text', '')).strip():
        raise ValueError('Enunciado obrigatório.')
    answers = q.get('answers')
    if not isinstance(answers, list) or not 1 <= len(answers) <= 20:
        raise ValueError('Informe entre 1 e 20 respostas.')
    seen = set()
    for a in answers:
        if not isinstance(a, dict) or not normalize(a.get('text', '')):
            raise ValueError('Resposta inválida.')
        if type(a.get('points')) is not int or not 0 <= a['points'] <= 10000:
            raise ValueError('Pontos devem ser inteiros entre 0 e 10000.')
        if not isinstance(a.get('synonyms', []), list) or any(not isinstance(s, str) for s in a.get('synonyms', [])):
            raise ValueError('Sinônimos devem ser uma lista de textos.')
        for text in [a['text']] + a.get('synonyms', []):
            key = normalize(text)
            if not key or key in seen:
                raise ValueError('Resposta ou sinônimo duplicado/ambíguo.')
            seen.add(key)
    return q

class Game:
    def __init__(self):
        self.state = None
        self.history = []
        self.dirty = False

    def checkpoint(self):
        self.history.append(copy.deepcopy(self.state))
        self.history = self.history[-100:]
        self.dirty = True

    def create(self, config):
        names = [str(x).strip() for x in config.get('players', [])]
        mode = config.get('mode', MODES[2])
        chat = bool(config.get('chat', False))
        if mode not in MODES or not names or len(names) > 20 or any(not n or len(n) > 60 for n in names):
            raise ValueError('Modalidade ou participantes inválidos.')
        if len(set(map(normalize, names))) != len(names) or any(normalize(n) == 'chat' for n in names):
            raise ValueError('Nomes devem ser únicos; Chat é reservado.')
        if mode in MODES[:2] and (not chat or len(names) != 1):
            raise ValueError('Esta modalidade exige um participante e chat habilitado.')
        if mode == MODES[2] and len(names) != 2:
            raise ValueError('Cadastre exatamente duas equipes.')
        if mode == MODES[3] and len(names) != 1:
            raise ValueError('Solo exige um jogador ou equipe.')
        if mode == MODES[4] and len(names) < 2:
            raise ValueError('Cadastre pelo menos dois jogadores.')
        rounds, errors = int(config.get('rounds', 3)), int(config.get('errors', 3))
        seconds, vote_seconds = int(config.get('seconds', 30)), int(config.get('vote_seconds', 45))
        multiplier = int(config.get('multiplier', 1))
        if not (1 <= rounds <= 100 and 1 <= errors <= 20 and 1 <= seconds <= 3600 and 1 <= vote_seconds <= 3600 and 1 <= multiplier <= 100):
            raise ValueError('Configurações fora dos limites.')
        command = str(config.get('command', '!r')).strip()
        if not re.fullmatch(r'![\w-]{1,20}', command):
            raise ValueError('Comando inválido.')
        role = 'direto' if mode in MODES[:2] else config.get('chat_role', 'desafiante')
        if role not in ('direto', 'desafiante'):
            raise ValueError('Papel do chat inválido.')
        tie = config.get('vote_tie', 'primeiro')
        if tie not in ('primeiro', 'alfabético'):
            raise ValueError('Critério de empate inválido.')
        self.checkpoint()
        self.state = dict(config=dict(mode=mode, chat=chat, chat_role=role, rounds=rounds, errors=errors,
            seconds=seconds, vote_seconds=vote_seconds, multiplier=multiplier, command=command, vote_tie=tie),
            players=names + (['Chat'] if chat else []), scores={n: 0 for n in names + (['Chat'] if chat else [])},
            phase='preparação', round=0, question=None, revealed=[], failed=[], errors={}, turn=None,
            pot=0, awarded=False, used=[], votes={}, vote_events=[], message_ids=[], vote_result=None,
            deadline=None, remaining=seconds, pending_turn=None, tie_players=[], winner=[])

    def eligible(self):
        s = self.state
        names = s['tie_players'] or s['players']
        return [n for n in names if n != 'Chat' or s['config']['chat_role'] == 'direto']

    def tick(self):
        s = self.state
        if s and s['deadline'] and time.time() >= s['deadline']:
            self.checkpoint()
            if s['phase'] == 'votação':
                self.close_vote()
            elif s['phase'] == 'resposta':
                s['deadline'] = None
                s['remaining'] = 0
                self.error()

    def start_round(self, question):
        s = self.state
        if s['phase'] not in ('preparação', 'encerrada'):
            raise ValueError('Encerre a rodada atual primeiro.')
        validate_question(question)
        round_rules = dict(s['config'])
        overrides = question.get('rules', {})
        if not isinstance(overrides, dict): raise ValueError('Regras especiais inválidas.')
        for key, maximum in (('seconds', 3600), ('vote_seconds', 3600), ('errors', 20), ('multiplier', 100)):
            if key in overrides:
                value = int(overrides[key])
                if not 1 <= value <= maximum: raise ValueError('Regra especial fora dos limites.')
                round_rules[key] = value
        if not question.get('approved'):
            raise ValueError('A pergunta precisa estar aprovada.')
        if s['round'] >= s['config']['rounds']:
            high = max(s['scores'].values())
            leaders = [n for n in s['players'] if s['scores'][n] == high]
            if len(leaders) == 1:
                s['phase'], s['winner'] = 'finalizada', leaders
                return
            s['tie_players'] = leaders
        s['round_rules'] = round_rules
        s.update(phase='resposta', round=s['round'] + 1, question=copy.deepcopy(question), revealed=[],
                 failed=[], errors={}, pot=0, awarded=False, votes={}, vote_events=[], message_ids=[],
                 vote_result=None, deadline=None, remaining=s.get('round_rules', s['config'])['seconds'], pending_turn=None, winner=[])
        candidates = self.eligible()
        s['turn'] = candidates[0] if candidates else 'Chat'
        s['used'].append(question['id'])

    def match(self, text):
        for i, a in enumerate(self.state['question']['answers']):
            if normalize(text) in [normalize(t) for t in [a['text']] + a.get('synonyms', [])]:
                return i
        return None

    def reveal(self, index):
        s = self.state
        if s['phase'] != 'resposta' or s['pending_turn'] or s['turn'] == 'Chat':
            raise ValueError('Não é possível revelar agora.')
        if type(index) is not int or not 0 <= index < len(s['question']['answers']) or index in s['revealed']:
            raise ValueError('Resposta inválida ou já revelada.')
        s['revealed'].append(index)
        s['pot'] += s['question']['answers'][index]['points'] * s.get('round_rules', s['config'])['multiplier']
        s['deadline'] = None
        s['remaining'] = s.get('round_rules', s['config'])['seconds']
        if len(s['revealed']) == len(s['question']['answers']):
            self.award(s['turn'])

    def error(self):
        s = self.state
        if s['phase'] != 'resposta' or s['pending_turn']:
            raise ValueError('Não é possível registrar erro agora.')
        who = s['turn']
        s['errors'][who] = s['errors'].get(who, 0) + 1
        s['deadline'] = None
        s['remaining'] = s.get('round_rules', s['config'])['seconds']
        if s['errors'][who] >= s.get('round_rules', s['config'])['errors']:
            s['failed'].append(who)
            remaining = [n for n in self.eligible() if n not in s['failed']]
            if remaining:
                s['pending_turn'] = remaining[0]
            else:
                challenge = s['config']['chat'] and s['config']['chat_role'] == 'desafiante' and (not s['tie_players'] or 'Chat' in s['tie_players'])
                s['phase'] = 'aguardando chat' if challenge else 'sem vencedor'

    def award(self, who):
        s = self.state
        if s['awarded'] or who not in s['scores']:
            raise ValueError('Pontuação já atribuída ou participante inválido.')
        s['scores'][who] += s['pot']
        s.update(awarded=True, phase='encerrada', deadline=None)
        if s['round'] >= s['config']['rounds']:
            high = max(s['scores'].values())
            leaders = [n for n in s['players'] if s['scores'][n] == high]
            if len(leaders) == 1:
                s.update(phase='finalizada', winner=leaders)

    def open_vote(self):
        s = self.state
        direct = s['phase'] == 'resposta' and s['turn'] == 'Chat' and not s['pending_turn']
        if s['phase'] != 'aguardando chat' and not direct:
            raise ValueError('O chat ainda não pode votar.')
        s.update(phase='votação', votes={}, vote_events=[], message_ids=[], vote_result=None,
                 deadline=time.time() + s.get('round_rules', s['config'])['vote_seconds'], vote_direct=direct)

    def vote(self, user, text, message_id):
        s = self.state
        self.tick()
        if s['phase'] != 'votação':
            raise ValueError('Votação fechada.')
        if not isinstance(user, str) or not isinstance(text, str) or not isinstance(message_id, str) or not 1 <= len(user) <= 128 or not 1 <= len(message_id) <= 256 or len(text) > 1000 or message_id in s['message_ids']:
            raise ValueError('Usuário inválido ou mensagem duplicada.')
        command, _, answer = text.strip().partition(' ')
        if command.casefold() != s['config']['command'].casefold() or not normalize(answer):
            raise ValueError('Comando ou resposta inválida.')
        if len(s['message_ids']) >= 50000:
            raise ValueError('Limite de mensagens da votação atingido.')
        key = normalize(answer)
        # Sinônimos da mesma resposta contam juntos; nenhuma resposta é enviada ao telão.
        index = self.match(answer)
        if index is not None:
            key = normalize(s['question']['answers'][index]['text'])
        s['message_ids'].append(message_id)
        s['votes'][str(user)] = key
        s['vote_events'].append(dict(Counter(s['votes'].values())))

    def close_vote(self):
        s = self.state
        if s['phase'] != 'votação':
            raise ValueError('Não há votação aberta.')
        counts = Counter(s['votes'].values())
        winner = None
        if counts:
            top = max(counts.values())
            tied = [k for k, v in counts.items() if v == top]
            if s['config']['vote_tie'] == 'alfabético':
                winner = min(tied)
            else:
                # Primeiro a atingir a contagem final, considerando trocas de voto.
                winner = min(tied, key=lambda k: next(i for i, event in enumerate(s['vote_events']) if event.get(k) == top))
        index = self.match(winner) if winner else None
        s.update(phase='resultado pendente', deadline=None,
                 vote_result=dict(answer=winner, index=index, correct=index is not None and index not in s['revealed'], total=len(s['votes'])))

    def confirm_vote(self):
        s = self.state
        if s['phase'] != 'resultado pendente':
            raise ValueError('Não há resultado para revelar.')
        r = s['vote_result']
        if r['correct']:
            s['revealed'].append(r['index'])
            s['pot'] += s['question']['answers'][r['index']]['points'] * s.get('round_rules', s['config'])['multiplier']
            if s.get('vote_direct') and len(s['revealed']) < len(s['question']['answers']):
                s.update(phase='resposta', remaining=s.get('round_rules', s['config'])['seconds'])
            else:
                self.award('Chat')
        elif s.get('vote_direct'):
            s['phase'] = 'resposta'
            self.error()
        else:
            s['phase'] = 'sem vencedor'

    def public(self):
        self.tick()
        s = self.state
        if not s:
            return {'phase': 'preparação', 'players': [], 'scores': {}, 'answers': []}
        q = s['question']
        return {k: copy.deepcopy(s[k]) for k in ('phase', 'round', 'players', 'scores', 'turn', 'errors', 'pot', 'winner')} | dict(
            question=q['text'] if q else '', category=q.get('category', '') if q else '',
            answers=[dict(number=i+1, text=a['text'], points=a['points']) if i in s['revealed'] else dict(number=i+1) for i, a in enumerate(q['answers'])] if q else [],
            seconds=max(0, int(s['deadline'] - time.time()+0.999)) if s['deadline'] else s['remaining'],
            simulation=True)

    def action(self, action, data):
        self.tick()
        if action == 'create':
            self.create(data)
            return
        if not self.state:
            raise ValueError('Crie uma partida primeiro.')
        if action == 'undo':
            if not self.history:
                raise ValueError('Nada para desfazer.')
            self.state = self.history.pop()
            if self.state:
                self.state['deadline'] = None
                if self.state['phase'] == 'votação':
                    self.state['deadline'] = time.time() + self.state['config']['vote_seconds']
            self.dirty = True
            return
        before = copy.deepcopy(self.state)
        dirty_before = self.dirty
        self.checkpoint()
        try:
            s = self.state
            if action == 'round': self.start_round(data['question'])
            elif action == 'reveal': self.reveal(data['index'])
            elif action == 'answer':
                index = self.match(data['text'])
                if index is None: self.error()
                else: self.reveal(index)
            elif action == 'error': self.error()
            elif action == 'open_vote': self.open_vote()
            elif action == 'close_vote': self.close_vote()
            elif action == 'confirm_vote': self.confirm_vote()
            elif action == 'vote': self.vote(data['user'], data['text'], data['message_id'])
            elif action == 'next_turn':
                if not s['pending_turn']: raise ValueError('Nenhum turno sugerido.')
                s.update(turn=s['pending_turn'], pending_turn=None)
            elif action == 'timer':
                if s['phase'] != 'resposta' or s['pending_turn'] or s['turn'] == 'Chat': raise ValueError('Cronômetro indisponível.')
                if s['deadline']:
                    s['remaining'] = max(0, s['deadline'] - time.time())
                    s['deadline'] = None
                else: s['deadline'] = time.time() + s['remaining']
            elif action == 'stop_timer':
                if s['phase'] != 'resposta': raise ValueError('Cronômetro indisponível.')
                s['deadline'] = None
                s['remaining'] = s.get('round_rules', s['config'])['seconds']
            elif action == 'end_game':
                s.update(phase='interrompida', deadline=None, winner=[])
            elif action == 'score':
                who, score = data['player'], int(data['score'])
                if who not in s['scores'] or abs(score) > 100000000: raise ValueError('Pontuação inválida.')
                s['scores'][who] = score
                if s['phase'] == 'finalizada':
                    high = max(s['scores'].values())
                    leaders = [n for n in s['players'] if s['scores'][n] == high]
                    s['winner'] = leaders if len(leaders) == 1 else []
                    if len(leaders) > 1: s['phase'] = 'encerrada'
            elif action == 'finish':
                if s['phase'] == 'sem vencedor': s['phase'] = 'encerrada'
                elif s['phase'] == 'resposta' and not s['pending_turn']: self.award(s['turn'])
                else: raise ValueError('Não é possível encerrar agora.')
            elif action == 'reset_round':
                if not s['question']: raise ValueError('Nenhuma rodada para reiniciar.')
                if s['awarded']: raise ValueError('Desfaça a atribuição de pontos antes de reiniciar.')
                q = s['question']; s['round'] -= 1; s['phase'] = 'encerrada'; self.start_round(q)
            else: raise ValueError('Ação desconhecida.')
        except Exception:
            self.state = before
            self.dirty = dirty_before
            self.history.pop()
            raise
