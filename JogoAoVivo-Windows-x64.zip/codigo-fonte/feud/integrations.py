"""Adaptadores opcionais. Nenhum é necessário para partidas offline."""
import base64
import hashlib
import json
import os
import ssl
import threading
import time
import uuid
from urllib.parse import urlencode, urlparse
from urllib.request import Request, urlopen


def request_json(url, data=None, headers=None, form=False):
    payload = None if data is None else (urlencode(data).encode() if form else json.dumps(data).encode())
    req = Request(url, data=payload, headers={'Content-Type': 'application/x-www-form-urlencoded' if form else 'application/json', **(headers or {})})
    with urlopen(req, timeout=30) as r:
        return json.load(r)


class AI:
    def generate(self, config):
        endpoint = config.get('endpoint') or os.getenv('FEUD_AI_URL', 'https://api.openai.com/v1')
        key = config.get('key') or os.getenv('FEUD_AI_KEY', '')
        model = config.get('model') or os.getenv('FEUD_AI_MODEL', '')
        if not key or not model: raise ValueError('Informe a chave e o modelo do provedor.')
        parsed = urlparse(endpoint)
        if parsed.scheme != 'https' or parsed.username or parsed.password: raise ValueError('O provedor exige uma URL HTTPS sem credenciais na URL.')
        result = request_json(endpoint.rstrip('/')+'/chat/completions', {
            'model': model, 'messages': [
                {'role':'system','content':'Gere uma pergunta para um jogo brasileiro de auditório. Responda apenas JSON com text, category, difficulty e answers (lista de text, points inteiro e synonyms lista de textos). Pontuações são inventadas/simuladas. Não afirme que são pesquisa. Não use Markdown.'},
                {'role':'user','content': str(config.get('prompt', 'Cultura brasileira'))[:2000]}],
            'temperature': .8}, {'Authorization': 'Bearer '+key})
        text = result['choices'][0]['message']['content'].strip()
        if text.startswith('```'): text = text.split('\n',1)[1].rsplit('```',1)[0]
        question = json.loads(text)
        from .game import validate_question
        validate_question(question)
        question.update(approved=False, origin='IA externa; pontuação simulada')
        return question


class OBS:
    def __init__(self):
        self.ws = None
        self.status = 'Desconectado'
        self.lock = threading.Lock()
        self.previous = {}
        self.scene = "Jogoliveborto — " + uuid.uuid4().hex[:8]
        self.config = None
        self.labels = {}

    def connect(self, config):
        import websocket
        self.disconnect()
        port = int(config.get('port',4455))
        if not 1 <= port <= 65535: raise ValueError('Porta OBS inválida.')
        self.ws = websocket.create_connection(f'ws://127.0.0.1:{port}', timeout=5, http_no_proxy=['127.0.0.1','localhost'])
        try:
            hello = json.loads(self.ws.recv())['d']
            identify = {'rpcVersion': 1, 'eventSubscriptions':0}
            if 'authentication' in hello:
                auth = hello['authentication']
                secret = base64.b64encode(hashlib.sha256((config.get('password','')+auth['salt']).encode()).digest()).decode()
                identify['authentication'] = base64.b64encode(hashlib.sha256((secret+auth['challenge']).encode()).digest()).decode()
            self.ws.send(json.dumps({'op':1,'d':identify}))
            if json.loads(self.ws.recv())['op'] != 2: raise ValueError('Autenticação OBS recusada.')
            self.status = 'Conectado'
            self.config = dict(config)
            return self.call('GetInputList')
        except Exception:
            self.disconnect()
            raise ValueError('Falha ao conectar ao OBS. Confira porta e senha locais.')

    def call(self, kind, data=None):
        if self.status == 'Conexão interrompida' and self.config:
            self.connect(self.config)
        if not self.ws: raise ValueError('OBS desconectado.')
        with self.lock:
            try:
                ident = str(uuid.uuid4())
                self.ws.send(json.dumps({'op':6,'d':{'requestType':kind,'requestId':ident,'requestData':data or {}}}))
                while True:
                    msg = json.loads(self.ws.recv())
                    if msg.get('op') == 7 and msg['d']['requestId'] == ident:
                        result = msg['d']
                        if not result['requestStatus']['result']:
                            raise ValueError(result['requestStatus'].get('comment','Operação OBS recusada.'))
                        return result.get('responseData', {})
            except ValueError: raise
            except Exception:
                self.status = 'Conexão interrompida'
                raise ValueError('OBS desconectou. A partida continua disponível.')

    def layout(self, data):
        cameras = data.get('cameras', [])
        if not isinstance(cameras,list) or len(cameras)>5: raise ValueError('Selecione até cinco câmeras.')
        # Cena exclusiva do aplicativo: não alterar cenas preexistentes.
        scene = self.scene
        scenes = self.call('GetSceneList')['scenes']
        if not any(s['sceneName']==scene for s in scenes): self.call('CreateScene', {'sceneName':scene})
        items = self.call('GetSceneItemList', {'sceneName':scene})['sceneItems']
        sources = {i['sourceName']:i['sceneItemId'] for i in items}
        result=[]
        for index, camera in enumerate(cameras):
            name = str(camera['source'])
            if name not in sources:
                sources[name] = self.call('CreateSceneItem',{'sceneName':scene,'sourceName':name})['sceneItemId']
            item_id = sources[name]
            old = self.call('GetSceneItemTransform',{'sceneName':scene,'sceneItemId':item_id})['sceneItemTransform']
            self.previous[(scene,item_id)] = old
            transform = {'positionX':float(camera.get('x',(index%2)*960)), 'positionY':float(camera.get('y',(index//2)*360)),
                'boundsType':'OBS_BOUNDS_SCALE_INNER','boundsWidth':float(camera.get('width',960)), 'boundsHeight':float(camera.get('height',360))}
            self.call('SetSceneItemTransform',{'sceneName':scene,'sceneItemId':item_id,'sceneItemTransform':transform})
            label = str(camera.get('name', name))[:100]
            if label:
                if index not in self.labels:
                    kinds = self.call('GetInputKindList')['inputKinds']
                    text_kind = next((k for k in ('text_gdiplus_v3', 'text_gdiplus_v2', 'text_ft2_source_v2') if k in kinds), None)
                    if not text_kind: raise ValueError('OBS não oferece uma fonte de texto compatível para os nomes.')
                    label_name = self.scene + ' — nome ' + str(index+1)
                    created = self.call('CreateInput', {'sceneName':scene, 'inputName':label_name, 'inputKind':text_kind,
                        'inputSettings':{'text':label,'font':{'face':'Arial','size':36,'flags':1},'color':0xFFFFFFFF,'outline':True},'sceneItemEnabled':True})
                    self.labels[index] = (label_name, created['sceneItemId'])
                label_name, label_id = self.labels[index]
                self.call('SetInputSettings', {'inputName':label_name,'inputSettings':{'text':label},'overlay':True})
                self.call('SetSceneItemTransform', {'sceneName':scene,'sceneItemId':label_id,
                    'sceneItemTransform':{'positionX':transform['positionX']+16,'positionY':transform['positionY']+transform['boundsHeight']-64}})
            result.append({'source':name,'item_id':item_id,'name':label})
        return {'scene':scene,'items':result}

    def highlight(self,data):
        scene=self.scene
        item_id=int(data['item_id'])
        old=self.call('GetSceneItemTransform',{'sceneName':scene,'sceneItemId':item_id})['sceneItemTransform']
        self.previous.setdefault((scene,item_id),old)
        return self.call('SetSceneItemTransform',{'sceneName':scene,'sceneItemId':item_id,'sceneItemTransform':{'positionX':0,'positionY':0,'boundsType':'OBS_BOUNDS_SCALE_INNER','boundsWidth':1920,'boundsHeight':1080}})

    def restore(self):
        for (scene,item_id),transform in self.previous.items():
            self.call('SetSceneItemTransform',{'sceneName':scene,'sceneItemId':item_id,'sceneItemTransform':transform})
        self.previous={}
        return {}

    def disconnect(self):
        if self.ws:
            self.ws.close()
        self.ws=None
        self.status='Desconectado'


class Twitch:
    def __init__(self, callback):
        self.callback=callback
        self.status='Desconectado'
        self.stop=threading.Event()
        self.ws=None
        self.thread=None

    def device(self, client_id):
        self.client_id=client_id
        self.device_data=request_json('https://id.twitch.tv/oauth2/device',{'client_id':client_id,'scopes':'user:read:chat'},form=True)
        self.device_started=time.time()
        self.last_poll=0
        return {k:v for k,v in self.device_data.items() if k!='device_code'}

    def authorize(self, broadcaster):
        if not getattr(self,'device_data',None): raise ValueError('Solicite a autorização primeiro.')
        if time.time()-self.device_started>self.device_data['expires_in']: raise ValueError('Código expirado. Solicite outra autorização.')
        if time.time()-self.last_poll<self.device_data['interval']: raise ValueError('Aguarde o intervalo indicado antes de verificar novamente.')
        self.last_poll=time.time()
        token=request_json('https://id.twitch.tv/oauth2/token',{'client_id':self.client_id,'device_code':self.device_data['device_code'],'grant_type':'urn:ietf:params:oauth:grant-type:device_code'},form=True)
        self.token=token['access_token']
        self.refresh_token=token.get('refresh_token')
        self.expires_at=time.time()+token.get('expires_in',3600)
        validation=request_json('https://id.twitch.tv/oauth2/validate',headers={'Authorization':'OAuth '+self.token})
        headers={'Authorization':'Bearer '+self.token,'Client-Id':self.client_id}
        users=request_json('https://api.twitch.tv/helix/users?'+urlencode({'login':broadcaster}),headers=headers)['data']
        if not users: raise ValueError('Canal não encontrado.')
        self.user_id=validation['user_id'];self.broadcaster_id=users[0]['id']
        self.disconnect()
        self.stop=threading.Event()
        self.thread=threading.Thread(target=self.run,args=(self.stop,),daemon=True)
        self.thread.start()
        return {'status':'Conectando'}

    def run(self, stop):
        import websocket
        target='wss://eventsub.wss.twitch.tv/ws'
        while not stop.is_set():
            try:
                if time.time()>self.expires_at-60 and self.refresh_token:
                    refreshed=request_json('https://id.twitch.tv/oauth2/token',{'client_id':self.client_id,'grant_type':'refresh_token','refresh_token':self.refresh_token},form=True)
                    self.token=refreshed['access_token'];self.refresh_token=refreshed.get('refresh_token',self.refresh_token);self.expires_at=time.time()+refreshed.get('expires_in',3600)
                ws=websocket.create_connection(target,timeout=40,sslopt={'cert_reqs':ssl.CERT_REQUIRED})
                self.ws=ws
                self.status='Conectando'
                while not stop.is_set():
                    msg=json.loads(ws.recv())
                    kind=msg['metadata']['message_type']
                    if kind=='session_welcome':
                        if target=='wss://eventsub.wss.twitch.tv/ws':
                            request_json('https://api.twitch.tv/helix/eventsub/subscriptions',{'type':'channel.chat.message','version':'1',
                                'condition':{'broadcaster_user_id':self.broadcaster_id,'user_id':self.user_id},
                                'transport':{'method':'websocket','session_id':msg['payload']['session']['id']}},
                                {'Authorization':'Bearer '+self.token,'Client-Id':self.client_id})
                        self.status='Conectado'
                    elif kind=='session_reconnect':
                        new=msg['payload']['session']['reconnect_url']
                        if urlparse(new).hostname!='eventsub.wss.twitch.tv': raise ValueError('Destino de reconexão inválido.')
                        target=new
                        break
                    elif kind=='notification':
                        event=msg['payload']['event']
                        self.callback(event['chatter_user_id'],event['message']['text'],event['message_id'])
                    elif kind=='revocation':
                        self.status='Autorização revogada';stop.set();break
            except Exception:
                if not stop.is_set(): self.status='Falha de conexão / autorização; nova tentativa em 5 s'
                target='wss://eventsub.wss.twitch.tv/ws'
            finally:
                if 'ws' in locals(): ws.close()
            stop.wait(5)

    def disconnect(self):
        self.stop.set()
        if self.ws: self.ws.close()
        if self.thread and self.thread is not threading.current_thread(): self.thread.join(timeout=2)
        self.status='Desconectado'
