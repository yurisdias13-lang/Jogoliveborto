import csv
import io
import json
from .game import validate_question, normalize

def preview(text, kind, existing, mapping=None):
    if kind == 'json':
        rows = json.loads(text)
        if isinstance(rows, dict): rows = rows.get('questions', [])
    elif kind == 'csv':
        rows = list(csv.DictReader(io.StringIO(text)))
    else: raise ValueError('Formato não suportado nesta versão. Converta XLSX para CSV ou JSON.')
    if not isinstance(rows, list) or len(rows) > 2000: raise ValueError('Importe uma lista de até 2000 perguntas.')
    seen = {normalize(q['text']) for q in existing}
    valid, errors = [], []
    for i, raw in enumerate(rows, 1):
        try:
            q = dict(raw)
            if mapping: q = {target: raw.get(source) for target, source in mapping.items() if source}
            if isinstance(q.get('answers'), str): q['answers'] = json.loads(q['answers'])
            validate_question(q)
            if normalize(q['text']) in seen: raise ValueError('Enunciado duplicado.')
            seen.add(normalize(q['text']))
            q.pop('id', None)
            q['approved'] = False
            valid.append(q)
        except (ValueError, TypeError) as e: errors.append({'row': i, 'error': str(e)})
    return dict(valid=valid, errors=errors)


def xlsx_json(encoded):
    import base64
    import zipfile
    from openpyxl import load_workbook
    raw = base64.b64decode(encoded, validate=True)
    archive = zipfile.ZipFile(io.BytesIO(raw))
    if sum(i.file_size for i in archive.infolist()) > 20_000_000:
        raise ValueError('Planilha descompactada excede 20 MB.')
    book = load_workbook(io.BytesIO(raw), read_only=True, data_only=True, keep_links=False)
    try:
        rows = book.active.iter_rows(values_only=True)
        headers = next(rows, None)
        if not headers: raise ValueError('Planilha vazia.')
        result=[]
        for row in rows:
            if len(result)>=2000: raise ValueError('Limite de 2000 perguntas por planilha.')
            if any(v is not None for v in row): result.append(dict(zip(headers,row)))
        return json.dumps(result, ensure_ascii=False, default=str)
    finally:
        book.close()
