# Inicialização do ambiente

Cada tarefa na nuvem já é isolada. Use o checkout existente em `/workspace/Jogoliveborto`; não crie um worktree sem solicitação explícita do usuário.

Dependências ficam em `.venv`; dados de partidas são locais e não precisam de credenciais. Use `.venv/bin/python` para executar o projeto. Se a preparação precisar ser refeita, execute `bash scripts/setup.sh` na raiz do projeto. Isso instala as versões de `requirements.txt` e executa os testes.

Inicie a aplicação com `.venv/bin/python main.py --data-dir /workspace/.jogoliveborto` no diretório `/workspace/Jogoliveborto`. A janela do navegador aberta pelo processo contém a autorização privada no fragmento da URL; não registre nem compartilhe esse token. A aplicação escuta somente em loopback, porta 8765. O processo deve ser reiniciado em cada tarefa que precise do aplicativo; processos em execução não sobrevivem à restauração do ambiente.

Para validação automatizada, use um `App` e `ThreadingHTTPServer` em uma porta local livre com banco temporário, conforme `tests/test_system.py`. Confira uma resposta funcional de `/api/public` e o fluxo de cadastro, partida, revelação e salvamento. Uma porta aberta não valida a aplicação. Não publique links de loopback como prévias na interface de onboarding.

`main.py --no-browser --data-dir /tmp/feud-smoke` permite iniciar o serviço sem abrir janela. Não expõe o token do painel em logs. Pare somente processos iniciados por você. A interface Windows incorporada usa `desktop.py`, exige pywebview e deve ser validada no Windows. Leia README.md para compilação e limitações das integrações.

Twitch, OBS e IA são opcionais. Não solicite credenciais para testar partidas offline. Credenciais devem ser configuradas em campos protegidos do painel local ou em `.env` ignorado pelo Git, nunca em instruções salvas. Nesta configuração não há credenciais externas fornecidas. Acesso a Twitch e ao provedor de IA pode exigir domínios adicionais nas configurações de rede; preserve as regras existentes. Não instale um cliente VPN.
