$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
py -3 -m venv .venv
if ($LASTEXITCODE -ne 0) { throw 'Python 3 não disponível.' }
& .\.venv\Scripts\python.exe -m pip install -r requirements-windows.txt
if ($LASTEXITCODE -ne 0) { throw 'Falha na instalação.' }
& .\.venv\Scripts\python.exe -m unittest discover -s tests -v
if ($LASTEXITCODE -ne 0) { throw 'Testes falharam.' }
& .\.venv\Scripts\python.exe -m PyInstaller --noconfirm --onefile --windowed --name JogoAoVivo --add-data 'web;web' desktop.py
if ($LASTEXITCODE -ne 0) { throw 'Falha no empacotamento.' }
