# Family Feud para Twitch — Documento de Requisitos da V1

**Status:** Especificação para implementação  
**Plataforma:** Windows  
**Idioma:** Português brasileiro  
**Tipo:** Aplicativo local com interface web incorporada  
**Objetivo:** Realizar partidas de um jogo inspirado em Family Feud durante transmissões na Twitch, com apresentador, jogadores, equipes, participação do chat e integração com OBS Studio.

## 1. Princípios obrigatórios

1. O apresentador nunca compete e tem controle exclusivo da partida.
2. O programa deve funcionar sem Twitch e sem OBS para partidas e testes locais.
3. Todas as respostas ocultas devem permanecer invisíveis na tela pública até serem reveladas.
4. O programa deve ser distribuído como executável Windows.
5. Nenhuma funcionalidade deve ser apresentada como operacional quando for apenas uma simulação.
6. A lógica do jogo deve ser independente das interfaces visuais e integrações externas.
7. A aplicação não depende de servidor hospedado na internet.
8. Não utilizar IA local.
9. Todas as interfaces devem estar em português brasileiro.

## 2. Modalidades de jogo

O sistema deve permitir selecionar, antes de cada partida:

- Um jogador individual contra o chat.
- Uma equipe contra o chat.
- Duas equipes, com possibilidade de roubo pelo chat.
- Um jogador ou equipe jogando sozinho, com o chat como desafiante após as falhas.
- Competição individual entre jogadores, com participação configurável do chat.

O chat poderá assumir dois papéis:

**Competidor direto:** participa da disputa desde o início, seguindo as regras de turnos da modalidade.

**Desafiante:** recebe uma oportunidade de roubo quando todos os participantes elegíveis falharem.

O apresentador não participa da pontuação.

O sistema deve permitir partidas com o chat desativado.

## 3. Regras das rodadas

- Número de rodadas configurável.
- Tempo de resposta configurável por modalidade.
- Limite de erros configurável.
- Multiplicadores de pontos configuráveis.
- Critérios de roubo configuráveis.
- Resultado determinado pela maior pontuação após a última rodada.
- Empates resolvidos por rodada adicional de desempate.
- Participantes empatados na liderança disputam o desempate.
- Rodadas especiais podem ter regras e multiplicadores próprios.

A mecânica de uma rodada deverá ser implementada como uma máquina de estados, evitando ações incompatíveis, como votar depois do encerramento ou atribuir os mesmos pontos a duas equipes.

## 4. Chat como desafiante

Regras obrigatórias:

1. O chat somente recebe sua oportunidade após todos os jogadores ou equipes elegíveis falharem.
2. O apresentador autoriza manualmente a abertura da votação.
3. A votação dura 45 segundos por padrão.
4. Os espectadores utilizam um comando personalizável, inicialmente `!r`.
5. Cada usuário tem um voto válido por votação.
6. Um novo voto substitui o anterior.
7. A resposta mais votada é escolhida.
8. O sistema verifica automaticamente se a resposta vencedora é correta.
9. Se acertar, o chat recebe todos os pontos acumulados naquela rodada.
10. Se errar, ou não houver votos válidos, perde a oportunidade de roubo.
11. Os pontos roubados não podem ser atribuídos simultaneamente a outra equipe.

Empates na votação devem seguir uma regra determinística e configurável, com padrão sugerido de priorizar a resposta que atingiu primeiro a contagem final empatada.

Ao encerrar o tempo, o sistema congela os votos e prepara o resultado. A revelação pública continua dependendo da confirmação do apresentador.

## 5. Perguntas e respostas

O sistema deve possuir um banco local de perguntas organizado nas seguintes categorias:

- Conhecimentos e situações cotidianas.
- Humor e perguntas absurdas.
- Games e cultura gamer.
- Memes, internet e Twitch.
- Cultura brasileira.
- Futebol e esportes.
- Categorias personalizadas.

Cada pergunta deve conter:

- Identificador único.
- Enunciado.
- Categoria e dificuldade.
- Quantidade variável de respostas.
- Respostas oficiais.
- Sinônimos aceitos.
- Pontuação de cada resposta.
- Origem da pergunta.
- Indicador de pergunta aprovada.
- Histórico de utilização.
- Data de criação e atualização.

As perguntas poderão ser escolhidas manualmente ou sorteadas. Perguntas utilizadas devem ser evitadas em sorteios posteriores, com controle para quando o banco disponível acabar.

## 6. Reconhecimento automático

O mecanismo deve normalizar:

- Maiúsculas e minúsculas.
- Acentos.
- Espaços duplicados.
- Pontuação desnecessária.
- Variações cadastradas de singular e plural.
- Sinônimos previamente definidos.

Reconhecimento aproximado por similaridade textual pode ser utilizado com limites conservadores.

Não aceitar automaticamente respostas apenas por conterem palavras semelhantes quando houver risco de significado diferente.

As respostas devem poder ser corrigidas manualmente pelo apresentador.

O reconhecimento de votos não deve depender de uma chamada à IA externa a cada mensagem da Twitch.

## 7. Inteligência artificial

A IA deverá ser utilizada para:

- Gerar perguntas.
- Sugerir respostas.
- Sugerir pontuações.
- Gerar sinônimos.
- Classificar categorias.
- Identificar possíveis perguntas duplicadas.

Requisitos:

- Utilizar exclusivamente APIs externas.
- Permitir selecionar um provedor e modelo compatíveis.
- Permitir configuração pelo painel ou arquivo `.env`.
- Manter credenciais fora do código da interface.
- Permitir testar a conexão.
- Exibir erros e falhas de geração.
- Exigir revisão e aprovação antes de incorporar perguntas ao banco.
- Permitir editar todas as respostas e pontuações geradas.
- Identificar pontuações inventadas como simuladas, nunca como pesquisa real.

A ausência de conexão com a IA não pode impedir o funcionamento do jogo com perguntas existentes.

## 8. Importação e banco compartilhado

Aceitar:

- JSON.
- CSV.
- Excel `.xlsx`.

O sistema deve oferecer:

- Visualização prévia dos dados.
- Mapeamento de colunas.
- Validação de formatos.
- Identificação de duplicidades.
- Relatório de erros.
- Importação parcial controlada.
- Cancelamento antes da confirmação.

Devem existir um banco privado e uma biblioteca compartilhável por meio de pacotes importados.

Na V1 não haverá sincronização entre computadores ou contas pela internet.

## 9. Painel do apresentador

O painel administrativo deverá permitir:

- Criar e configurar partidas.
- Selecionar modalidades.
- Cadastrar jogadores e equipes.
- Escolher perguntas.
- Visualizar respostas corretas.
- Iniciar, pausar e encerrar cronômetros.
- Confirmar respostas.
- Revelar posições do tabuleiro.
- Registrar erros.
- Controlar a pontuação.
- Abrir e fechar votações.
- Avançar turnos.
- Desfazer ações.
- Corrigir pontuações e respostas.
- Reiniciar uma rodada.
- Selecionar câmeras.
- Destacar participantes.
- Salvar e carregar partidas.

O avanço dos turnos deve ser sugerido automaticamente, mas exigir confirmação do apresentador.

Todos os atalhos de teclado devem ser personalizáveis.

## 10. Telão público

O visual inicial deve ser inspirado em programas clássicos de auditório.

Elementos:

- Tabuleiro de respostas.
- Respostas ocultas numeradas.
- Revelação animada.
- Pontuação por resposta.
- Placar de jogadores, equipes e chat.
- Indicador de erros.
- Cronômetro visível.
- Destaque de participante ou equipe.
- Efeitos de suspense.
- Animações de vitória e encerramento.

O telão será exibido no OBS como fonte de navegador, conectado ao serviço local do aplicativo.

O layout deve ser responsivo e suportar tela cheia ou composição com câmeras, sem exigir páginas públicas separadas.

As respostas ocultas não podem ser enviadas à interface pública antes da revelação.

## 11. Áudio e animações

Criar efeitos originais para:

- Resposta correta.
- Resposta incorreta.
- Revelação.
- Início e fim de votação.
- Contagem regressiva.
- Suspense.
- Roubo de pontos.
- Vitória.
- Encerramento.

Adicionar controles independentes de volume e possibilidade de silenciar os efeitos.

Impedir que sons sejam reproduzidos simultaneamente no painel administrativo e no telão, causando duplicação na transmissão.

## 12. Integração com OBS

O OBS será responsável por capturar as câmeras e gerenciar o áudio.

Suportar até cinco câmeras:

- Duas do Time A.
- Duas do Time B.
- Uma do apresentador, opcional.

O número de câmeras deve ser configurável antes de cada partida.

Funcionalidades:

- Detectar fontes disponíveis no OBS.
- Associar fontes aos participantes.
- Posicionar automaticamente.
- Permitir ajustes manuais.
- Salvar layouts.
- Selecionar manualmente uma câmera para destaque.
- Mostrar nomes e equipes.
- Restaurar a organização anterior.
- Reconectar quando possível.
- Exibir aviso quando o OBS desconectar.

A partida deve continuar normalmente se a conexão com o OBS cair.

A integração deverá preservar fontes e cenas preexistentes do usuário, evitando alterações destrutivas.

## 13. Twitch

Utilizar integração oficial compatível com cliente local.

Funcionalidades:

- Conectar e desconectar a conta da Twitch.
- Receber mensagens do canal autorizado.
- Interpretar comandos personalizáveis.
- Reconhecer o usuário pelo identificador da Twitch.
- Receber votos apenas durante a janela de votação.
- Atualizar a votação em tempo real no painel.
- Encerrar a votação após o período configurado.
- Evitar duplicidade de mensagens.
- Reconectar após interrupções.
- Exibir o estado da conexão.

A autorização da Twitch será necessária apenas para utilizar sua integração, não para abrir ou administrar o jogo.

## 14. Persistência e segurança

Armazenamento local em SQLite.

Salvar somente quando o apresentador solicitar, incluindo partidas em andamento.

Implementar:

- Indicador de alterações não salvas.
- Botão Salvar.
- Atalho configurável para salvar.
- Aviso ao encerrar com alterações pendentes.
- Carregamento de partidas salvas.
- Validação de arquivos importados.
- Proteção das credenciais externas.
- Comunicação local protegida.
- Registro básico de erros técnicos.

Sem salvamento automático de partidas na V1.

## 15. Testes offline

Implementar um modo de teste sem conexão com Twitch ou OBS.

Nesse modo, o apresentador poderá:

- Criar uma partida fictícia.
- Simular mensagens de espectadores.
- Simular votações.
- Simular erros e acertos.
- Verificar pontuações.
- Testar cronômetros.
- Testar revelações.
- Reiniciar rodadas.
- Conferir o layout público.

As simulações devem estar claramente identificadas.

## 16. Distribuição

Entregar um executável para Windows, com instalador ou versão portátil, conforme viabilidade técnica.

O aplicativo deve:

- Iniciar sua interface sem comandos manuais.
- Iniciar automaticamente os serviços locais necessários.
- Armazenar dados em diretório gravável do usuário.
- Fechar corretamente serviços e conexões ao encerrar.
- Permitir acesso fácil às configurações.
- Informar dependências externas e erros de conexão.

O código-fonte e as instruções de compilação devem acompanhar o projeto.

## 17. Requisitos não funcionais

- Separar lógica, interface, banco e integrações.
- Não deixar o telão travar quando a Twitch desconectar.
- Não revelar respostas ocultas por engano.
- Tratar erros sem encerrar inesperadamente o programa.
- Evitar perda ou duplicação de pontos.
- Manter interface utilizável em 1920 × 1080.
- Validar entradas externas.
- Incluir testes automatizados para as regras centrais.
- Utilizar bibliotecas mantidas e compatíveis com Windows.
- Garantir que os controles apresentados sejam operacionais.
- Documentar funções não implementadas, sem simular que estejam concluídas.