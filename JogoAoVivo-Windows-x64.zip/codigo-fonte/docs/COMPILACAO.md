# Executável Windows x64

Artefato: `JogoAoVivo.exe`, aplicativo gráfico PE32+ x86-64, versão portátil.

A compilação usou o Python 3.12.10 para Windows, distribuído pela Python Software Foundation no pacote NuGet `python`, PyInstaller 6.11.1 e as dependências de `requirements-windows.txt`. Pacotes foram baixados por HTTPS com validação TLS. Wine foi instalado dos repositórios oficiais assinados do Debian. A consulta WMI não implementada no Wine 8 foi substituída pelo fallback de registro/ambiente do módulo `platform` apenas na ferramenta de build. Esse ajuste foi excluído do executável.

Validação realizada:

- 31 testes de regras, persistência, HTTP, importação e contratos dos adaptadores passaram com o Python para Windows sob Wine.
- Estrutura PE x64, recursos web, bibliotecas WebView2, Python.Runtime.dll e módulos Windows foram conferidos no arquivo empacotado.
- O próprio executável passou em Wine 10 no modo `--self-test`, sem montar o código-fonte nem configurar um Python externo. Foram exercitados os recursos incorporados, HTTP local, ocultação das respostas, revelação, salvamento/carregamento SQLite e importação XLSX.

O modo não gráfico pode ser repetido em Windows com `JogoAoVivo.exe --self-test relatorio.json`. O relatório deve conter `passed: true`. Não inicia Twitch, OBS ou IA nem utiliza credenciais.

A interface gráfica incorporada depende do Microsoft Edge WebView2 Runtime e do .NET Framework compatível com pywebview/pythonnet. A janela e as integrações externas ainda precisam de teste em um Windows real. O resultado sob Wine não substitui essa validação.

Para recompilar nativamente, use `build-windows.ps1`. O pacote ZIP de distribuição inclui o código-fonte correspondente em `codigo-fonte/`, uma biblioteca de exemplo e o relatório de verificação. Nenhuma credencial ou partida do usuário é incluída.
