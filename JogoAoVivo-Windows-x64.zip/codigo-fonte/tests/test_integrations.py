"""Testes dos adaptadores com respostas controladas; não validam contas externas."""
import unittest
from unittest.mock import patch
from feud.integrations import AI, OBS

class Adapters(unittest.TestCase):
    def test_ai_requires_https_and_credentials(self):
        with self.assertRaises(ValueError): AI().generate({'endpoint':'http://example.org','model':'modelo','key':'chave-ficticia'})

    @patch('feud.integrations.request_json')
    def test_ai_only_returns_unapproved_draft(self, request):
        request.return_value={'choices':[{'message':{'content':'{"text":"Um alimento?","answers":[{"text":"Arroz","points":50,"synonyms":[]}]}'}}]}
        result=AI().generate({'endpoint':'https://example.org/v1','model':'teste','key':'chave-ficticia'})
        self.assertFalse(result['approved'])
        self.assertIn('simulada',result['origin'])
        self.assertEqual(request.call_args.args[0],'https://example.org/v1/chat/completions')

    def test_obs_layout_never_alters_existing_scenes(self):
        obs=OBS();calls=[]
        def call(kind,data=None):
            calls.append((kind,data))
            return {'GetSceneList':{'scenes':[{'sceneName':'Cena existente'}]},'GetSceneItemList':{'sceneItems':[]},'CreateSceneItem':{'sceneItemId':7},'GetSceneItemTransform':{'sceneItemTransform':{'positionX':10}},'GetInputKindList':{'inputKinds':['text_gdiplus_v3']},'CreateInput':{'sceneItemId':8}}.get(kind,{})
        obs.call=call
        result=obs.layout({'cameras':[{'source':'Câmera 1','name':'Ana • Time A'}]})
        self.assertEqual(result['items'][0]['item_id'],7)
        for kind,data in calls:
            if data and 'sceneName' in data:self.assertEqual(data['sceneName'],obs.scene)
        self.assertFalse(any(kind in ('RemoveInput','RemoveScene','RemoveSceneItem') for kind,_ in calls))
        self.assertTrue(any(kind=='CreateInput' and data['inputSettings']['text']=='Ana • Time A' for kind,data in calls))

if __name__=='__main__':unittest.main()
