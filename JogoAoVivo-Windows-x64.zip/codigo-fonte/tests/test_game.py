import copy
import unittest
from unittest.mock import patch
from feud.game import Game, normalize, validate_question, MODES

Q={'id':'q1','text':'O que tem no almoço?','category':'Cotidiano','approved':True,'answers':[
    {'text':'Arroz','points':40,'synonyms':['arroz branco']},
    {'text':'Feijão','points':35,'synonyms':['feijões']},
    {'text':'Carne','points':25,'synonyms':['bife']}]}

class Rules(unittest.TestCase):
    def setUp(self):
        self.g=Game()
        self.g.create(dict(players=['A','B'],chat=True,errors=1,rounds=1))
        self.g.action('round',{'question':Q})

    def fail_all(self):
        self.g.action('error',{})
        self.g.action('next_turn',{})
        self.g.action('error',{})

    def vote(self,user,text,mid=None):
        self.g.action('vote',{'user':user,'text':'!r '+text,'message_id':mid or user+text})

    def test_normalize(self):
        self.assertEqual(normalize('  FEIJÃO!!!  '),'feijao')
        self.assertEqual(self.g.match(' FEIJÕES '),1)
        self.assertIsNone(self.g.match('arroz estragado'))

    def test_no_hidden_data(self):
        public=self.g.public()
        self.assertNotIn('text',public['answers'][0])
        self.assertNotIn('question',str(public['answers']))
        self.g.action('reveal',{'index':0})
        public=self.g.public()
        self.assertEqual(public['answers'][0]['text'],'Arroz')
        self.assertNotIn('text',public['answers'][1])

    def test_no_early_vote(self):
        with self.assertRaises(ValueError):self.g.action('open_vote',{})
        self.g.action('error',{})
        with self.assertRaises(ValueError):self.g.action('open_vote',{})

    def test_turn_confirmation(self):
        self.g.action('error',{})
        with self.assertRaises(ValueError):self.g.action('reveal',{'index':0})
        self.assertEqual(self.g.state['turn'],'A')
        self.g.action('next_turn',{})
        self.assertEqual(self.g.state['turn'],'B')

    def test_steal_awarded_once(self):
        self.g.action('reveal',{'index':0})
        self.fail_all()
        self.g.action('open_vote',{})
        self.vote('1','feijao')
        self.g.action('close_vote',{})
        self.assertEqual(self.g.state['scores']['Chat'],0)
        self.assertNotIn('text',self.g.public()['answers'][1])
        self.g.action('confirm_vote',{})
        self.assertEqual(self.g.state['scores'],{'A':0,'B':0,'Chat':75})
        with self.assertRaises(ValueError):self.g.action('confirm_vote',{})
        with self.assertRaises(ValueError):self.g.action('finish',{})

    def test_vote_replace_and_deduplicate(self):
        self.fail_all();self.g.action('open_vote',{})
        self.vote('1','arroz','m1');self.vote('1','carne','m2')
        self.vote('2','bife','m3')
        with self.assertRaises(ValueError):self.vote('3','feijao','m3')
        self.g.action('close_vote',{})
        self.assertEqual(self.g.state['vote_result']['answer'],'carne')
        self.assertEqual(self.g.state['vote_result']['total'],2)
        with self.assertRaises(ValueError):self.vote('3','arroz','m4')

    def test_deterministic_tie(self):
        self.fail_all();self.g.action('open_vote',{})
        self.vote('1','carne');self.vote('2','arroz')
        self.g.action('close_vote',{})
        self.assertEqual(self.g.state['vote_result']['answer'],'carne')

    def test_expired_vote_rejected(self):
        self.fail_all();self.g.action('open_vote',{})
        self.g.state['deadline']=1
        with self.assertRaises(ValueError):self.vote('1','arroz')
        self.assertEqual(self.g.state['phase'],'resultado pendente')

    def test_empty_vote_no_points(self):
        self.fail_all();self.g.action('open_vote',{});self.g.action('close_vote',{});self.g.action('confirm_vote',{})
        self.assertEqual(self.g.state['phase'],'sem vencedor')
        self.assertEqual(sum(self.g.state['scores'].values()),0)

    def test_no_double_reveal(self):
        self.g.action('reveal',{'index':0})
        with self.assertRaises(ValueError):self.g.action('reveal',{'index':0})
        self.assertEqual(self.g.state['pot'],40)

    def test_undo(self):
        self.g.action('reveal',{'index':0});self.g.action('undo',{})
        self.assertEqual(self.g.state['revealed'],[])
        self.assertEqual(self.g.state['pot'],0)

    def test_timeout_registers_error(self):
        self.g.action('timer',{});self.g.state['deadline']=1;self.g.tick()
        self.assertEqual(self.g.state['errors']['A'],1)
        self.assertEqual(self.g.state['pending_turn'],'B')

    def test_tie_round_leaders_only(self):
        self.g.state['scores']={'A':40,'B':40,'Chat':0}
        self.fail_all();self.g.action('open_vote',{});self.g.action('close_vote',{});self.g.action('confirm_vote',{});self.g.action('finish',{})
        self.g.action('round',{'question':Q})
        self.assertEqual(self.g.eligible(),['A','B'])
        self.fail_all()
        self.assertEqual(self.g.state['phase'],'sem vencedor')

    def test_direct_chat(self):
        g=Game();g.create(dict(mode=MODES[0],players=['A'],chat=True,errors=1))
        g.action('round',{'question':Q});g.action('error',{});g.action('next_turn',{})
        g.action('open_vote',{});g.action('vote',{'user':'u','text':'!r arroz','message_id':'m'})
        g.action('close_vote',{});g.action('confirm_vote',{})
        self.assertEqual(g.state['pot'],40)
        self.assertEqual(g.state['phase'],'resposta')
        self.assertEqual(g.state['turn'],'Chat')

    def test_unapproved_rejected(self):
        g=Game();g.create({'players':['A','B']})
        with self.assertRaises(ValueError):g.action('round',{'question':dict(Q,approved=False)})

    def test_round_specific_rules(self):
        g=Game();g.create(dict(players=['A','B'],errors=3,multiplier=1,seconds=30))
        g.action('round',{'question':dict(Q,rules={'multiplier':3,'errors':1,'seconds':10})})
        g.action('reveal',{'index':0})
        self.assertEqual(g.state['pot'],120)
        self.assertEqual(g.state['remaining'],10)
        g.action('error',{})
        self.assertEqual(g.state['pending_turn'],'B')
        self.assertEqual(g.state['config']['errors'],3)

    def test_ambiguous_synonyms_rejected(self):
        q=copy.deepcopy(Q);q['answers'][1]['synonyms']=['arroz']
        with self.assertRaises(ValueError):validate_question(q)

    def test_failed_action_keeps_saved_status(self):
        self.g.dirty=False
        with self.assertRaises(ValueError):self.g.action('reveal',{'index':999})
        self.assertFalse(self.g.dirty)

    def test_interrupt_stops_clock_and_votes(self):
        self.g.action('timer',{})
        self.g.action('end_game',{})
        self.assertIsNone(self.g.state['deadline'])
        with self.assertRaises(ValueError):self.g.action('open_vote',{})
        with self.assertRaises(ValueError):self.g.action('reveal',{'index':0})

    def test_bad_action_atomic(self):
        before=copy.deepcopy(self.g.state)
        with self.assertRaises(ValueError):self.g.action('reveal',{'index':999})
        self.assertEqual(self.g.state,before)

if __name__=='__main__':unittest.main()
