import base64
import io
import json
from pathlib import Path
import tempfile
import threading
import unittest
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from http.server import ThreadingHTTPServer
from feud.server import App, handler
from feud.store import Store
from feud.importing import preview, xlsx_json
from test_game import Q

class System(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.app=App(Path(self.temp.name)/'test.sqlite3')
        self.server=ThreadingHTTPServer(('127.0.0.1',0),handler(self.app))
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.url='http://127.0.0.1:'+str(self.server.server_port)

    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.thread.join();self.app.store.db.close();self.temp.cleanup()

    def call(self,path,data=None,token=True):
        headers={'Content-Type':'application/json'}
        if token:headers['X-Admin-Token']=self.app.token
        with urlopen(Request(self.url+path,data=None if data is None else json.dumps(data).encode(),headers=headers)) as r:return json.load(r)

    def test_full_offline_workflow_and_public_privacy(self):
        self.call('/api/question',Q)
        self.call('/api/create',{'players':['A','B']})
        self.call('/api/round',{'id':'q1'})
        public=self.call('/api/public',token=False)
        self.assertNotIn('Arroz',json.dumps(public));self.assertNotIn('Feijão',json.dumps(public,ensure_ascii=False))
        self.call('/api/reveal',{'index':0})
        self.assertEqual(self.call('/api/public',token=False)['answers'][0]['text'],'Arroz')
        self.call('/api/save',{'name':'Teste'})
        self.call('/api/reveal',{'index':1})
        save=self.call('/api/admin')['saves'][0]
        self.call('/api/load',{'id':save['id'],'discard':True})
        self.assertEqual(self.app.game.state['revealed'],[0])
        self.assertFalse(self.app.game.dirty)

    def test_admin_requires_token(self):
        with self.assertRaises(HTTPError) as ctx:self.call('/api/admin',token=False)
        self.assertEqual(ctx.exception.code,401)
        with self.assertRaises(HTTPError) as ctx:self.call('/api/create',{'players':['A','B']},token=False)
        self.assertEqual(ctx.exception.code,403)

    def test_cross_origin_rejected(self):
        req=Request(self.url+'/api/create',data=b'{}',headers={'X-Admin-Token':self.app.token,'Origin':'https://evil.example'})
        with self.assertRaises(HTTPError) as ctx:urlopen(req)
        self.assertEqual(ctx.exception.code,403)

    def test_static_files(self):
        for path in ['/','/public','/app.js','/public.js','/style.css']:
            with urlopen(self.url+path) as r:self.assertEqual(r.status,200);self.assertTrue(r.read())

    def test_import_preview_cancel_confirmation(self):
        p=self.call('/api/import_preview',{'kind':'json','text':json.dumps([Q,{'text':'Inválida'}])})
        self.assertEqual(len(p['valid']),1);self.assertEqual(len(p['errors']),1)
        self.assertEqual(self.app.store.questions(),[])
        self.call('/api/import_cancel',{})
        self.assertEqual(self.app.store.questions(),[])
        self.call('/api/import_preview',{'kind':'json','text':json.dumps([Q])})
        self.call('/api/import_confirm',{})
        self.assertFalse(self.app.store.questions()[0]['approved'])

    def test_xlsx(self):
        from openpyxl import Workbook
        book=Workbook();sheet=book.active
        sheet.append(['text','answers']);sheet.append([Q['text'],json.dumps(Q['answers'])])
        stream=io.BytesIO();book.save(stream)
        text=xlsx_json(base64.b64encode(stream.getvalue()).decode())
        result=preview(text,'json',[])
        self.assertEqual(len(result['valid']),1)

    def test_duplicate_import(self):
        result=preview(json.dumps([Q]),'json',[Q])
        self.assertEqual(len(result['errors']),1)

    def test_no_implicit_save(self):
        self.call('/api/create',{'players':['A','B']})
        self.assertEqual(self.app.store.saves(),[])

if __name__=='__main__':unittest.main()
